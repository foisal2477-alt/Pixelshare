"use client";

import Link from "next/link";
import { useState, useEffect } from "react";
import {
  Upload,
  Shield,
  ShieldCheck,
  Image as ImageIcon,
  LogOut,
  Sparkles,
} from "lucide-react";

interface NavbarProps {
  onOpenUpload: () => void;
  isAdmin?: boolean;
  onAdminLogout?: () => void;
}

export default function Navbar({
  onOpenUpload,
  isAdmin: propIsAdmin,
  onAdminLogout,
}: NavbarProps) {
  const [isAdmin, setIsAdmin] = useState<boolean>(propIsAdmin ?? false);

  useEffect(() => {
    if (propIsAdmin !== undefined) {
      setIsAdmin(propIsAdmin);
      return;
    }
    // Check admin status
    fetch("/api/admin/auth")
      .then((res) => res.json())
      .then((data) => {
        setIsAdmin(!!data.isAdmin);
      })
      .catch(() => {});
  }, [propIsAdmin]);

  const handleLogout = async () => {
    try {
      await fetch("/api/admin/auth", { method: "DELETE" });
      setIsAdmin(false);
      if (onAdminLogout) onAdminLogout();
      window.location.reload();
    } catch (err) {
      console.error("Logout failed:", err);
    }
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-200/80 bg-white/90 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        {/* Brand */}
        <div className="flex items-center gap-3">
          <Link
            href="/"
            className="flex items-center gap-2.5 text-slate-900 transition-opacity hover:opacity-90"
          >
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-tr from-indigo-600 via-indigo-500 to-sky-400 text-white shadow-md shadow-indigo-500/20">
              <ImageIcon className="h-5 w-5" />
            </div>
            <div>
              <span className="text-lg font-bold tracking-tight text-slate-900">
                PixelShare
              </span>
              <span className="hidden text-xs text-slate-500 sm:block">
                Open Image Community
              </span>
            </div>
          </Link>

          <span className="hidden items-center gap-1.5 rounded-full bg-emerald-50 px-2.5 py-1 text-xs font-medium text-emerald-700 ring-1 ring-emerald-600/20 md:inline-flex">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" />
            Public Uploads Active
          </span>
        </div>

        {/* Action buttons */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Main Upload Button - For Everyone */}
          <button
            onClick={onOpenUpload}
            className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 px-4 py-2.5 text-sm font-semibold text-white shadow-md shadow-indigo-600/25 transition-all hover:from-indigo-500 hover:to-violet-500 hover:shadow-lg active:scale-95 cursor-pointer"
            id="upload-button-nav"
          >
            <Upload className="h-4 w-4" />
            <span>Upload Image</span>
            <span className="hidden text-[10px] uppercase font-bold tracking-wider bg-white/20 px-1.5 py-0.5 rounded sm:inline">
              Free
            </span>
          </button>

          {/* Admin link or controls */}
          {isAdmin ? (
            <div className="flex items-center gap-1.5 sm:gap-2">
              <Link
                href="/admin"
                className="inline-flex items-center gap-1.5 rounded-xl bg-amber-500/10 px-3 py-2 text-xs sm:text-sm font-medium text-amber-900 ring-1 ring-amber-500/30 transition-colors hover:bg-amber-500/20"
              >
                <ShieldCheck className="h-4 w-4 text-amber-600" />
                <span className="hidden sm:inline">Admin</span> Dashboard
              </Link>
              <button
                onClick={handleLogout}
                title="Log out of Admin"
                className="inline-flex h-9 w-9 items-center justify-center rounded-xl border border-slate-200 text-slate-600 transition-colors hover:bg-slate-100 hover:text-slate-900"
              >
                <LogOut className="h-4 w-4" />
              </button>
            </div>
          ) : (
            <Link
              href="/admin"
              className="inline-flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs sm:text-sm font-medium text-slate-700 transition-colors hover:border-slate-300 hover:bg-slate-50"
              id="admin-portal-link"
            >
              <Shield className="h-3.5 w-3.5 text-slate-500" />
              <span>Admin</span>
            </Link>
          )}
        </div>
      </div>
    </header>
  );
}
