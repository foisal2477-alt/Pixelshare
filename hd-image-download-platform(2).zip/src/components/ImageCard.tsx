"use client";

import { useState } from "react";
import {
  Heart,
  Eye,
  Download,
  Share2,
  Trash2,
  Star,
  EyeOff,
  User,
  Calendar,
} from "lucide-react";
import { ImageItem } from "@/lib/types";
import { formatDate, getClientToken } from "@/lib/client-utils";

interface ImageCardProps {
  image: ImageItem;
  onClick: () => void;
  isAdmin?: boolean;
  onDelete?: (id: string) => void;
  onToggleFeature?: (id: string, current: boolean) => void;
  onToggleVisibility?: (id: string, current: boolean) => void;
}

export default function ImageCard({
  image,
  onClick,
  isAdmin,
  onDelete,
  onToggleFeature,
  onToggleVisibility,
}: ImageCardProps) {
  const [likesCount, setLikesCount] = useState(image.likesCount || 0);
  const [isLiked, setIsLiked] = useState(false);
  const [isLiking, setIsLiking] = useState(false);
  const [imageLoaded, setImageLoaded] = useState(false);
  const [imageError, setImageError] = useState(false);

  const handleLike = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isLiking) return;
    setIsLiking(true);

    try {
      const clientToken = getClientToken();
      const res = await fetch(`/api/images/${image.id}/like`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ clientToken }),
      });
      const data = await res.json();
      if (res.ok) {
        setLikesCount(data.likesCount);
        setIsLiked(data.isLiked);
      }
    } catch (err) {
      console.error("Failed to like:", err);
    } finally {
      setIsLiking(false);
    }
  };

  const handleDownload = (e: React.MouseEvent) => {
    e.stopPropagation();
    const link = document.createElement("a");
    link.href = image.imageUrl;
    link.download = image.fileName || `${image.title.replace(/\s+/g, "-")}.jpg`;
    link.target = "_blank";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div
      onClick={onClick}
      className="group relative flex flex-col overflow-hidden rounded-2xl bg-white shadow-sm ring-1 ring-slate-900/5 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:ring-slate-900/10 cursor-pointer"
    >
      {/* Image container */}
      <div className="relative aspect-[4/3] w-full overflow-hidden bg-slate-100">
        {!imageLoaded && !imageError && (
          <div className="absolute inset-0 animate-pulse bg-slate-200" />
        )}

        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={image.imageUrl}
          alt={image.title}
          loading="lazy"
          onLoad={() => setImageLoaded(true)}
          onError={() => {
            setImageLoaded(true);
            setImageError(true);
          }}
          className={`h-full w-full object-cover transition-transform duration-500 group-hover:scale-105 ${
            imageLoaded ? "opacity-100" : "opacity-0"
          }`}
        />

        {imageError && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-slate-100 p-4 text-center text-slate-400">
            <span className="text-xs">Preview unavailable</span>
          </div>
        )}

        {/* Category & Status badges */}
        <div className="absolute left-3 top-3 flex flex-wrap items-center gap-1.5 z-10">
          {image.category && (
            <span className="rounded-lg bg-black/60 px-2.5 py-1 text-[11px] font-semibold text-white backdrop-blur-md">
              {image.category}
            </span>
          )}
          {image.isFeatured && (
            <span className="inline-flex items-center gap-1 rounded-lg bg-amber-500/90 px-2 py-1 text-[11px] font-semibold text-white shadow-sm backdrop-blur-md">
              <Star className="h-3 w-3 fill-current" />
              Featured
            </span>
          )}
          {!image.isVisible && (
            <span className="inline-flex items-center gap-1 rounded-lg bg-rose-600/90 px-2 py-1 text-[11px] font-semibold text-white shadow-sm backdrop-blur-md">
              <EyeOff className="h-3 w-3" />
              Hidden
            </span>
          )}
        </div>

        {/* Top-Right Quick Actions */}
        <div className="absolute right-3 top-3 flex items-center gap-1.5 opacity-90 transition-opacity group-hover:opacity-100 z-10">
          <button
            onClick={handleLike}
            title={isLiked ? "Unlike" : "Like"}
            className={`flex items-center gap-1.5 rounded-xl px-2.5 py-1.5 text-xs font-semibold backdrop-blur-md transition-all active:scale-90 ${
              isLiked
                ? "bg-rose-500 text-white shadow-sm"
                : "bg-black/50 text-white hover:bg-black/70"
            }`}
          >
            <Heart
              className={`h-3.5 w-3.5 ${
                isLiked ? "fill-current" : ""
              }`}
            />
            <span>{likesCount}</span>
          </button>

          <button
            onClick={handleDownload}
            title="Download image"
            className="flex h-7 w-7 items-center justify-center rounded-xl bg-black/50 text-white backdrop-blur-md transition-colors hover:bg-black/70 active:scale-90"
          >
            <Download className="h-3.5 w-3.5" />
          </button>
        </div>

        {/* Admin Quick Overlay (if logged in as admin) */}
        {isAdmin && (
          <div
            onClick={(e) => e.stopPropagation()}
            className="absolute bottom-3 left-3 right-3 flex items-center justify-between rounded-xl bg-slate-900/90 px-3 py-1.5 text-xs text-white backdrop-blur-md shadow-lg transition-transform"
          >
            <span className="font-semibold text-amber-400">Admin</span>
            <div className="flex items-center gap-2">
              <button
                onClick={() => onToggleFeature?.(image.id, image.isFeatured)}
                title={image.isFeatured ? "Unfeature" : "Feature on top"}
                className={`rounded p-1 transition-colors ${
                  image.isFeatured ? "text-amber-400 hover:text-amber-300" : "text-slate-400 hover:text-white"
                }`}
              >
                <Star className={`h-4 w-4 ${image.isFeatured ? "fill-current" : ""}`} />
              </button>
              <button
                onClick={() => onToggleVisibility?.(image.id, image.isVisible)}
                title={image.isVisible ? "Hide from public" : "Show to public"}
                className={`rounded p-1 transition-colors ${
                  image.isVisible ? "text-emerald-400 hover:text-emerald-300" : "text-rose-400 hover:text-rose-300"
                }`}
              >
                {image.isVisible ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
              </button>
              <button
                onClick={() => onDelete?.(image.id)}
                title="Delete image"
                className="rounded p-1 text-rose-400 hover:text-rose-300"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Card Info */}
      <div className="flex flex-1 flex-col justify-between p-4">
        <div>
          <h3 className="line-clamp-1 text-sm font-semibold text-slate-900 group-hover:text-indigo-600">
            {image.title}
          </h3>
          {image.description && (
            <p className="mt-1 line-clamp-2 text-xs text-slate-500">
              {image.description}
            </p>
          )}
        </div>

        <div className="mt-3 flex items-center justify-between border-t border-slate-100 pt-3 text-[11px] text-slate-500">
          <div className="flex items-center gap-1.5 truncate">
            <User className="h-3.5 w-3.5 shrink-0 text-slate-400" />
            <span className="truncate font-medium text-slate-700">
              {image.uploaderName || "Anonymous"}
            </span>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <span className="flex items-center gap-1 text-slate-400">
              <Eye className="h-3 w-3" />
              {image.viewsCount || 0}
            </span>
            <span>{formatDate(image.createdAt)}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
