"use client";

import { useEffect, useState } from "react";
import {
  X,
  Heart,
  Eye,
  Download,
  Share2,
  Trash2,
  Calendar,
  User,
  Tag,
  FileCheck,
  Check,
  Star,
  EyeOff,
} from "lucide-react";
import { ImageItem } from "@/lib/types";
import { formatDate, formatFileSize, getClientToken } from "@/lib/client-utils";

interface ImageDetailModalProps {
  image: ImageItem | null;
  isOpen: boolean;
  onClose: () => void;
  isAdmin?: boolean;
  onDelete?: (id: string) => void;
  onToggleFeature?: (id: string, current: boolean) => void;
  onToggleVisibility?: (id: string, current: boolean) => void;
  onTagClick?: (tag: string) => void;
}

export default function ImageDetailModal({
  image,
  isOpen,
  onClose,
  isAdmin,
  onDelete,
  onToggleFeature,
  onToggleVisibility,
  onTagClick,
}: ImageDetailModalProps) {
  const [likesCount, setLikesCount] = useState<number>(0);
  const [isLiked, setIsLiked] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);
  const [confirmDelete, setConfirmDelete] = useState<boolean>(false);

  useEffect(() => {
    if (image) {
      setLikesCount(image.likesCount || 0);
      setIsLiked(false);
      setConfirmDelete(false);

      // Increment view count via GET
      fetch(`/api/images/${image.id}`)
        .then((res) => res.json())
        .then((data) => {
          if (data.image) {
            setLikesCount(data.image.likesCount || 0);
          }
        })
        .catch(() => {});
    }
  }, [image]);

  if (!isOpen || !image) return null;

  const handleLike = async () => {
    try {
      const clientToken = getClientToken();
      const res = await fetch(`/api/images/${image.id}/like`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ clientToken }),
      });
      const data = await res.json();
      if (res.ok) {
        setLikesCount(data.likesCount);
        setIsLiked(data.isLiked);
      }
    } catch (err) {
      console.error("Like error:", err);
    }
  };

  const handleDownload = () => {
    const link = document.createElement("a");
    link.href = image.imageUrl;
    link.download = image.fileName || `${image.title.replace(/\s+/g, "-")}.jpg`;
    link.target = "_blank";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(window.location.origin + "?id=" + image.id);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const tagsList = image.tags
    ? image.tags
        .split(",")
        .map((t) => t.trim())
        .filter(Boolean)
    : [];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-2 sm:p-4 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative flex h-[95vh] w-full max-w-6xl flex-col overflow-hidden rounded-2xl bg-white shadow-2xl lg:flex-row">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute right-4 top-4 z-20 flex h-9 w-9 items-center justify-center rounded-full bg-black/60 text-white backdrop-blur-md transition-colors hover:bg-black/90 cursor-pointer"
        >
          <X className="h-5 w-5" />
        </button>

        {/* Left: Image Canvas */}
        <div className="relative flex flex-1 items-center justify-center bg-slate-950 p-4 sm:p-6 select-none overflow-hidden">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={image.imageUrl}
            alt={image.title}
            className="max-h-[82vh] w-auto max-w-full rounded-lg object-contain shadow-2xl"
          />
        </div>

        {/* Right: Info & Actions Sidebar */}
        <div className="flex w-full flex-col justify-between border-t border-slate-100 bg-white p-6 lg:w-96 lg:border-l lg:border-t-0 overflow-y-auto">
          <div className="space-y-5">
            {/* Header info */}
            <div>
              <div className="flex flex-wrap items-center gap-2 mb-2">
                {image.category && (
                  <span className="rounded-lg bg-indigo-50 px-2.5 py-1 text-xs font-semibold text-indigo-700 ring-1 ring-indigo-500/20">
                    {image.category}
                  </span>
                )}
                {image.isFeatured && (
                  <span className="inline-flex items-center gap-1 rounded-lg bg-amber-50 px-2.5 py-1 text-xs font-semibold text-amber-700 ring-1 ring-amber-500/20">
                    <Star className="h-3 w-3 fill-current" />
                    Featured
                  </span>
                )}
                {!image.isVisible && (
                  <span className="inline-flex items-center gap-1 rounded-lg bg-rose-50 px-2.5 py-1 text-xs font-semibold text-rose-700 ring-1 ring-rose-500/20">
                    <EyeOff className="h-3 w-3" />
                    Hidden
                  </span>
                )}
              </div>
              <h2 className="text-xl font-bold tracking-tight text-slate-900">
                {image.title}
              </h2>
            </div>

            {/* Uploader & Date */}
            <div className="flex items-center justify-between rounded-xl bg-slate-50 p-3 text-xs text-slate-600">
              <div className="flex items-center gap-2">
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-indigo-100 font-bold text-indigo-700">
                  {(image.uploaderName || "A")[0].toUpperCase()}
                </div>
                <div>
                  <p className="font-semibold text-slate-800">
                    {image.uploaderName || "Anonymous"}
                  </p>
                  <p className="text-[11px] text-slate-400">Contributor</p>
                </div>
              </div>
              <div className="text-right">
                <p className="font-medium text-slate-700">{formatDate(image.createdAt)}</p>
                <p className="text-[11px] text-slate-400">{image.viewsCount || 0} views</p>
              </div>
            </div>

            {/* Description */}
            {image.description && (
              <div>
                <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                  Description
                </h4>
                <p className="mt-1 text-sm leading-relaxed text-slate-700">
                  {image.description}
                </p>
              </div>
            )}

            {/* Tags */}
            {tagsList.length > 0 && (
              <div>
                <h4 className="mb-2 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-slate-400">
                  <Tag className="h-3.5 w-3.5" /> Tags
                </h4>
                <div className="flex flex-wrap gap-1.5">
                  {tagsList.map((tag) => (
                    <button
                      key={tag}
                      onClick={() => {
                        onClose();
                        onTagClick?.(tag);
                      }}
                      className="rounded-lg bg-slate-100 px-2.5 py-1 text-xs font-medium text-slate-600 hover:bg-indigo-50 hover:text-indigo-600"
                    >
                      #{tag}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Technical details */}
            <div className="rounded-xl border border-slate-100 p-3 text-xs text-slate-500 space-y-1.5">
              <div className="flex justify-between">
                <span>File Size:</span>
                <span className="font-medium text-slate-700">
                  {formatFileSize(image.fileSize)}
                </span>
              </div>
              <div className="flex justify-between">
                <span>Format:</span>
                <span className="font-medium text-slate-700 uppercase">
                  {image.mimeType?.replace("image/", "") || "JPG"}
                </span>
              </div>
              {image.fileName && (
                <div className="flex justify-between">
                  <span>File Name:</span>
                  <span className="max-w-[170px] truncate font-medium text-slate-700">
                    {image.fileName}
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Actions Footer */}
          <div className="mt-6 space-y-2.5 border-t border-slate-100 pt-4">
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={handleLike}
                className={`flex items-center justify-center gap-2 rounded-xl py-2.5 text-xs font-semibold transition-all active:scale-95 ${
                  isLiked
                    ? "bg-rose-50 text-rose-600 ring-1 ring-rose-300"
                    : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                }`}
              >
                <Heart
                  className={`h-4 w-4 ${
                    isLiked ? "fill-rose-500 text-rose-500" : ""
                  }`}
                />
                <span>{likesCount} Likes</span>
              </button>

              <button
                onClick={handleCopyLink}
                className="flex items-center justify-center gap-2 rounded-xl bg-slate-100 py-2.5 text-xs font-semibold text-slate-700 transition-colors hover:bg-slate-200"
              >
                {copied ? (
                  <>
                    <Check className="h-4 w-4 text-emerald-600" />
                    <span className="text-emerald-700">Copied!</span>
                  </>
                ) : (
                  <>
                    <Share2 className="h-4 w-4" />
                    <span>Share</span>
                  </>
                )}
              </button>
            </div>

            <button
              onClick={handleDownload}
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-indigo-600 py-2.5 text-xs font-semibold text-white shadow-md shadow-indigo-600/20 transition-all hover:bg-indigo-500"
            >
              <Download className="h-4 w-4" />
              <span>Download Image</span>
            </button>

            {/* Admin or Delete Controls */}
            {(isAdmin || true) && (
              <div className="pt-2">
                {confirmDelete ? (
                  <div className="flex items-center justify-between gap-2 rounded-xl bg-rose-50 p-2.5 text-xs ring-1 ring-rose-200">
                    <span className="text-rose-700 font-medium">Delete this image?</span>
                    <div className="flex gap-1.5">
                      <button
                        onClick={() => {
                          onDelete?.(image.id);
                          onClose();
                        }}
                        className="rounded-lg bg-rose-600 px-3 py-1 font-semibold text-white hover:bg-rose-700"
                      >
                        Yes, Delete
                      </button>
                      <button
                        onClick={() => setConfirmDelete(false)}
                        className="rounded-lg bg-white px-2.5 py-1 text-slate-700 hover:bg-slate-100 ring-1 ring-slate-200"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                ) : (
                  <button
                    onClick={() => setConfirmDelete(true)}
                    className="flex w-full items-center justify-center gap-1.5 rounded-xl py-2 text-xs font-medium text-slate-400 hover:bg-rose-50 hover:text-rose-600 transition-colors"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                    <span>Delete Image</span>
                  </button>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
