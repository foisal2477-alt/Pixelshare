"use client";

import { useState, useRef, ChangeEvent, DragEvent } from "react";
import {
  X,
  Upload,
  Link2,
  FileImage,
  CheckCircle2,
  AlertCircle,
  Loader2,
  Sparkles,
  Tag,
} from "lucide-react";
import { ImageItem } from "@/lib/types";
import { formatFileSize } from "@/lib/client-utils";

interface UploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUploadSuccess: (newImage: ImageItem) => void;
}

const CATEGORIES = [
  "General",
  "Nature",
  "Urban",
  "Architecture",
  "Art & Abstract",
  "Food",
  "Wildlife",
  "Tech",
  "Memes",
  "Wallpapers",
];

const POPULAR_TAGS = ["nature", "travel", "art", "night", "minimal", "street", "cozy", "landscape"];

export default function UploadModal({
  isOpen,
  onClose,
  onUploadSuccess,
}: UploadModalProps) {
  const [mode, setMode] = useState<"file" | "url">("file");
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string>("");
  const [imageUrlInput, setImageUrlInput] = useState<string>("");

  const [title, setTitle] = useState("");
  const [category, setCategory] = useState("General");
  const [tags, setTags] = useState("");
  const [uploaderName, setUploaderName] = useState("");
  const [description, setDescription] = useState("");

  const [isDragging, setIsDragging] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [successItem, setSuccessItem] = useState<ImageItem | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const resetForm = () => {
    setSelectedFile(null);
    setPreviewUrl("");
    setImageUrlInput("");
    setTitle("");
    setCategory("General");
    setTags("");
    setUploaderName("");
    setDescription("");
    setErrorMsg("");
    setSuccessItem(null);
    setIsLoading(false);
  };

  const handleClose = () => {
    resetForm();
    onClose();
  };

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processSelectedFile(file);
    }
  };

  const processSelectedFile = (file: File) => {
    setErrorMsg("");
    if (!file.type.startsWith("image/")) {
      setErrorMsg("Please select a valid image file (JPG, PNG, WEBP, GIF, SVG).");
      return;
    }
    if (file.size > 15 * 1024 * 1024) {
      setErrorMsg("Image size exceeds 15MB limit. Please choose a smaller image.");
      return;
    }

    setSelectedFile(file);
    const objectUrl = URL.createObjectURL(file);
    setPreviewUrl(objectUrl);

    // Auto-fill title if empty
    if (!title) {
      const cleanName = file.name
        .replace(/\.[^/.]+$/, "")
        .replace(/[-_]/g, " ");
      setTitle(cleanName.charAt(0).toUpperCase() + cleanName.slice(1));
    }
  };

  const handleDragOver = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processSelectedFile(file);
    }
  };

  const handleUrlPreview = () => {
    if (!imageUrlInput.trim()) return;
    setPreviewUrl(imageUrlInput.trim());
    if (!title) {
      setTitle("Web Image");
    }
  };

  const addTag = (tag: string) => {
    const currentTags = tags
      .split(",")
      .map((t) => t.trim())
      .filter(Boolean);
    if (!currentTags.includes(tag)) {
      currentTags.push(tag);
      setTags(currentTags.join(", "));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg("");
    setIsLoading(true);

    try {
      let res: Response;

      if (mode === "file") {
        if (!selectedFile) {
          setErrorMsg("Please choose an image file to upload.");
          setIsLoading(false);
          return;
        }

        const formData = new FormData();
        formData.append("file", selectedFile);
        formData.append("title", title.trim() || selectedFile.name);
        formData.append("category", category);
        formData.append("tags", tags.trim());
        formData.append("uploaderName", uploaderName.trim() || "Anonymous");
        formData.append("description", description.trim());

        res = await fetch("/api/upload", {
          method: "POST",
          body: formData,
        });
      } else {
        if (!imageUrlInput.trim()) {
          setErrorMsg("Please enter an image URL.");
          setIsLoading(false);
          return;
        }

        res = await fetch("/api/upload", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            imageUrl: imageUrlInput.trim(),
            title: title.trim() || "Web Image",
            category,
            tags: tags.trim(),
            uploaderName: uploaderName.trim() || "Anonymous",
            description: description.trim(),
            fileName: "web-image.jpg",
          }),
        });
      }

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || "Upload failed");
      }

      setSuccessItem(data.image);
      onUploadSuccess(data.image);
    } catch (err: any) {
      setErrorMsg(err.message || "Failed to upload image. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative flex max-h-[92vh] w-full max-w-2xl flex-col rounded-2xl bg-white shadow-2xl ring-1 ring-slate-900/10">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 px-6 py-4">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-indigo-50 text-indigo-600">
              <Upload className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-slate-900">
                Upload New Image
              </h2>
              <p className="text-xs text-slate-500">
                Everyone can upload images — free and open to all
              </p>
            </div>
          </div>
          <button
            onClick={handleClose}
            className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-600"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Body */}
        <div className="overflow-y-auto px-6 py-5">
          {successItem ? (
            <div className="flex flex-col items-center py-6 text-center">
              <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-emerald-100 text-emerald-600">
                <CheckCircle2 className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-bold text-slate-900">
                Image Uploaded Successfully!
              </h3>
              <p className="mt-1 text-sm text-slate-600">
                &ldquo;{successItem.title}&rdquo; is now live in the gallery for everyone to see.
              </p>

              <div className="my-5 max-h-56 overflow-hidden rounded-xl border border-slate-200 shadow-inner">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={successItem.imageUrl}
                  alt={successItem.title}
                  className="max-h-56 max-w-full object-contain"
                />
              </div>

              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={resetForm}
                  className="rounded-xl border border-slate-300 px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                >
                  Upload Another
                </button>
                <button
                  type="button"
                  onClick={handleClose}
                  className="rounded-xl bg-indigo-600 px-5 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500"
                >
                  View in Gallery
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-5">
              {errorMsg && (
                <div className="flex items-center gap-2 rounded-xl bg-rose-50 p-3 text-sm text-rose-700 ring-1 ring-rose-200">
                  <AlertCircle className="h-4 w-4 shrink-0" />
                  <span>{errorMsg}</span>
                </div>
              )}

              {/* Mode switch */}
              <div className="flex rounded-xl bg-slate-100 p-1">
                <button
                  type="button"
                  onClick={() => {
                    setMode("file");
                    setErrorMsg("");
                  }}
                  className={`flex flex-1 items-center justify-center gap-2 rounded-lg py-2 text-xs font-semibold transition-all ${
                    mode === "file"
                      ? "bg-white text-indigo-600 shadow-sm"
                      : "text-slate-600 hover:text-slate-900"
                  }`}
                >
                  <FileImage className="h-4 w-4" />
                  Upload from Device
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setMode("url");
                    setErrorMsg("");
                  }}
                  className={`flex flex-1 items-center justify-center gap-2 rounded-lg py-2 text-xs font-semibold transition-all ${
                    mode === "url"
                      ? "bg-white text-indigo-600 shadow-sm"
                      : "text-slate-600 hover:text-slate-900"
                  }`}
                >
                  <Link2 className="h-4 w-4" />
                  Paste Image URL
                </button>
              </div>

              {/* Upload Zone */}
              {mode === "file" ? (
                <div>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/jpeg,image/png,image/webp,image/gif,image/svg+xml"
                    onChange={handleFileChange}
                    className="hidden"
                  />
                  {!previewUrl ? (
                    <div
                      onDragOver={handleDragOver}
                      onDragLeave={handleDragLeave}
                      onDrop={handleDrop}
                      onClick={() => fileInputRef.current?.click()}
                      className={`flex cursor-pointer flex-col items-center justify-center rounded-2xl border-2 border-dashed p-8 text-center transition-all ${
                        isDragging
                          ? "border-indigo-500 bg-indigo-50/50"
                          : "border-slate-300 bg-slate-50 hover:border-indigo-400 hover:bg-slate-100/70"
                      }`}
                    >
                      <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-indigo-100 text-indigo-600">
                        <Upload className="h-6 w-6" />
                      </div>
                      <p className="text-sm font-semibold text-slate-800">
                        Click to browse or drag and drop image here
                      </p>
                      <p className="mt-1 text-xs text-slate-500">
                        Supports JPG, PNG, WEBP, GIF, SVG (up to 15MB)
                      </p>
                    </div>
                  ) : (
                    <div className="relative overflow-hidden rounded-2xl border border-slate-200 bg-slate-950 p-2">
                      <div className="flex max-h-56 items-center justify-center overflow-hidden rounded-xl bg-slate-900">
                        {/* eslint-disable-next-line @next/next/no-img-element */}
                        <img
                          src={previewUrl}
                          alt="Upload preview"
                          className="max-h-56 w-auto object-contain"
                        />
                      </div>
                      <div className="flex items-center justify-between px-3 py-2 text-xs text-white">
                        <div className="truncate">
                          <span className="font-semibold">{selectedFile?.name}</span>
                          <span className="ml-2 text-slate-400">
                            ({formatFileSize(selectedFile?.size)})
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            setSelectedFile(null);
                            setPreviewUrl("");
                          }}
                          className="rounded px-2 py-1 text-xs text-rose-300 hover:bg-rose-500/20 hover:text-rose-200"
                        >
                          Change
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="flex gap-2">
                    <input
                      type="url"
                      placeholder="https://example.com/photo.jpg"
                      value={imageUrlInput}
                      onChange={(e) => setImageUrlInput(e.target.value)}
                      className="flex-1 rounded-xl border border-slate-300 px-3.5 py-2.5 text-sm text-slate-900 focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                    />
                    <button
                      type="button"
                      onClick={handleUrlPreview}
                      className="rounded-xl bg-slate-100 px-4 py-2.5 text-xs font-semibold text-slate-700 hover:bg-slate-200"
                    >
                      Preview
                    </button>
                  </div>
                  {previewUrl && (
                    <div className="flex max-h-56 items-center justify-center overflow-hidden rounded-xl border border-slate-200 bg-slate-950 p-1">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        src={previewUrl}
                        alt="URL Preview"
                        className="max-h-52 w-auto object-contain"
                        onError={() => setErrorMsg("Could not load image from this URL.")}
                      />
                    </div>
                  )}
                </div>
              )}

              {/* Metadata Inputs */}
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <label className="mb-1 block text-xs font-semibold text-slate-700">
                    Image Title <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Golden Gate in Fog"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-sm text-slate-900 focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  />
                </div>

                <div>
                  <label className="mb-1 block text-xs font-semibold text-slate-700">
                    Category
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-sm text-slate-900 focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  >
                    {CATEGORIES.map((cat) => (
                      <option key={cat} value={cat}>
                        {cat}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="mb-1 block text-xs font-semibold text-slate-700">
                    Your Name / Nickname
                  </label>
                  <input
                    type="text"
                    placeholder="Anonymous (or your name)"
                    value={uploaderName}
                    onChange={(e) => setUploaderName(e.target.value)}
                    className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-sm text-slate-900 focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  />
                </div>

                <div>
                  <label className="mb-1 block text-xs font-semibold text-slate-700">
                    Tags (comma separated)
                  </label>
                  <input
                    type="text"
                    placeholder="nature, sunset, 4k"
                    value={tags}
                    onChange={(e) => setTags(e.target.value)}
                    className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-sm text-slate-900 focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  />
                </div>
              </div>

              {/* Tag quick suggestions */}
              <div className="flex flex-wrap items-center gap-1.5 pt-1">
                <span className="text-[11px] font-medium text-slate-400">Suggestions:</span>
                {POPULAR_TAGS.map((pt) => (
                  <button
                    key={pt}
                    type="button"
                    onClick={() => addTag(pt)}
                    className="rounded-full bg-slate-100 px-2.5 py-0.5 text-[11px] font-medium text-slate-600 transition-colors hover:bg-indigo-50 hover:text-indigo-600"
                  >
                    #{pt}
                  </button>
                ))}
              </div>

              <div>
                <label className="mb-1 block text-xs font-semibold text-slate-700">
                  Description / Story (Optional)
                </label>
                <textarea
                  rows={2}
                  placeholder="Tell others about this photo or artwork..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-sm text-slate-900 focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                />
              </div>

              {/* Actions */}
              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={handleClose}
                  disabled={isLoading}
                  className="rounded-xl border border-slate-200 px-4 py-2.5 text-sm font-medium text-slate-700 hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isLoading || (!selectedFile && !imageUrlInput)}
                  className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 px-5 py-2.5 text-sm font-semibold text-white shadow-md shadow-indigo-600/25 transition-all hover:from-indigo-500 hover:to-violet-500 disabled:opacity-50 cursor-pointer"
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" />
                      Uploading...
                    </>
                  ) : (
                    <>
                      <Upload className="h-4 w-4" />
                      Publish Image
                    </>
                  )}
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
