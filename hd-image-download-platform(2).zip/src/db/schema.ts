import { pgTable, text, varchar, integer, boolean, timestamp } from "drizzle-orm/pg-core";

export const images = pgTable("images", {
  id: varchar("id", { length: 64 }).primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  imageUrl: text("image_url").notNull(),
  thumbnailUrl: text("thumbnail_url"),
  fileName: varchar("file_name", { length: 255 }),
  fileSize: integer("file_size").default(0),
  mimeType: varchar("mime_type", { length: 100 }).default("image/jpeg"),
  category: varchar("category", { length: 100 }).default("General"),
  tags: text("tags").default(""),
  uploaderName: varchar("uploader_name", { length: 100 }).default("Anonymous"),
  isFeatured: boolean("is_featured").default(false).notNull(),
  isVisible: boolean("isVisible").default(true).notNull(),
  likesCount: integer("likes_count").default(0).notNull(),
  viewsCount: integer("views_count").default(0).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

export const systemSettings = pgTable("system_settings", {
  key: varchar("key", { length: 100 }).primaryKey(),
  value: text("value").notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

export const imageLikes = pgTable("image_likes", {
  id: varchar("id", { length: 64 }).primaryKey(),
  imageId: varchar("image_id", { length: 64 }).notNull(),
  clientToken: varchar("client_token", { length: 128 }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export type ImageItem = typeof images.$inferSelect;
export type NewImageItem = typeof images.$inferInsert;
