import { db } from "@/db";
import { images, systemSettings } from "@/db/schema";
import { count, eq } from "drizzle-orm";

export async function ensureSeeded() {
  try {
    // Check system settings
    const settingsCount = await db.select({ count: count() }).from(systemSettings);
    if (settingsCount[0]?.count === 0) {
      await db.insert(systemSettings).values([
        { key: "allow_public_uploads", value: "true" },
        { key: "admin_password", value: "admin123" },
        { key: "max_file_size_mb", value: "15" },
        { key: "site_name", value: "PixelShare Gallery" },
      ]);
    }

    // Check images count
    const imageCount = await db.select({ count: count() }).from(images);
    if (imageCount[0]?.count === 0) {
      const initialImages = [
        {
          id: "seed-1",
          title: "Misty Alpine Sunrise",
          description: "Golden morning rays cutting through deep mountain valleys in the Swiss Alps.",
          imageUrl: "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1600&q=80",
          fileName: "alpine-sunrise.jpg",
          fileSize: 1845200,
          mimeType: "image/jpeg",
          category: "Nature",
          tags: "nature, mountains, sunrise, alps, landscape",
          uploaderName: "Elena Vance",
          isFeatured: true,
          isVisible: true,
          likesCount: 42,
          viewsCount: 310,
        },
        {
          id: "seed-2",
          title: "Cyberpunk Tokyo Rain",
          description: "Reflections of neon signage and umbrellas in the vibrant alleyways of Shinjuku.",
          imageUrl: "https://images.unsplash.com/photo-1503899036084-c55cdd92da26?auto=format&fit=crop&w=1600&q=80",
          fileName: "tokyo-night-rain.jpg",
          fileSize: 2210400,
          mimeType: "image/jpeg",
          category: "Urban",
          tags: "urban, tokyo, cyberpunk, neon, night, rain",
          uploaderName: "Kenji Sato",
          isFeatured: true,
          isVisible: true,
          likesCount: 68,
          viewsCount: 524,
        },
        {
          id: "seed-3",
          title: "Minimal Geometric Architecture",
          description: "Striking spiral concrete stairs illuminated by soft natural skylight.",
          imageUrl: "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1600&q=80",
          fileName: "minimal-architecture.jpg",
          fileSize: 1420100,
          mimeType: "image/jpeg",
          category: "Architecture",
          tags: "architecture, minimal, modern, interior, geometry",
          uploaderName: "David Miller",
          isFeatured: false,
          isVisible: true,
          likesCount: 29,
          viewsCount: 198,
        },
        {
          id: "seed-4",
          title: "Vibrant Fluid Acrylics",
          description: "High resolution close-up capture of swirling liquid pigments and gold leaf flakes.",
          imageUrl: "https://images.unsplash.com/photo-1541701494587-cb58502866ab?auto=format&fit=crop&w=1600&q=80",
          fileName: "fluid-art.jpg",
          fileSize: 3120000,
          mimeType: "image/jpeg",
          category: "Art & Abstract",
          tags: "abstract, fluid, art, colorful, texture, acrylic",
          uploaderName: "Sofia Rossi",
          isFeatured: true,
          isVisible: true,
          likesCount: 84,
          viewsCount: 640,
        },
        {
          id: "seed-5",
          title: "Artisanal Shoyu Ramen",
          description: "Steaming bowl of rich pork bone broth ramen with ajitsuke tamago and nori.",
          imageUrl: "https://images.unsplash.com/photo-1569718212165-3a8278d5f624?auto=format&fit=crop&w=1600&q=80",
          fileName: "artisan-ramen.jpg",
          fileSize: 1650800,
          mimeType: "image/jpeg",
          category: "Food",
          tags: "food, ramen, noodles, gourmet, delicious",
          uploaderName: "Chef Tao",
          isFeatured: false,
          isVisible: true,
          likesCount: 37,
          viewsCount: 245,
        },
        {
          id: "seed-6",
          title: "Curious Red Fox in Snow",
          description: "Wildlife photography shot of a red fox gazing into the camera during winter snowfall.",
          imageUrl: "https://images.unsplash.com/photo-1516934024742-b461fba47600?auto=format&fit=crop&w=1600&q=80",
          fileName: "winter-fox.jpg",
          fileSize: 2040900,
          mimeType: "image/jpeg",
          category: "Wildlife",
          tags: "wildlife, fox, snow, winter, cute, animal",
          uploaderName: "Sarah Jenkins",
          isFeatured: false,
          isVisible: true,
          likesCount: 93,
          viewsCount: 780,
        },
      ];

      await db.insert(images).values(initialImages);
    }
  } catch (error) {
    console.error("Error in ensureSeeded:", error);
  }
}
