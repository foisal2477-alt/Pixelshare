export interface ImageItem {
  id: string;
  title: string;
  description: string | null;
  imageUrl: string;
  thumbnailUrl: string | null;
  fileName: string | null;
  fileSize: number | null;
  mimeType: string | null;
  category: string | null;
  tags: string | null;
  uploaderName: string | null;
  isFeatured: boolean;
  isVisible: boolean;
  likesCount: number;
  viewsCount: number;
  createdAt: string | Date;
  updatedAt: string | Date;
}

export interface AdminStats {
  totalImages: number;
  visibleImages: number;
  hiddenImages: number;
  featuredImages: number;
  totalViews: number;
  totalLikes: number;
  totalSizeBytes: number;
}

export interface SystemSettingsData {
  allowPublicUploads: boolean;
  maxFileSizeMb: number;
  siteName: string;
}
