import { cookies } from "next/headers";
import { db } from "@/db";
import { systemSettings } from "@/db/schema";
import { eq } from "drizzle-orm";

const ADMIN_COOKIE_NAME = "arena_admin_auth";
const ADMIN_SECRET = process.env.ADMIN_SECRET || "admin-secret-key-arena-2025";

export async function getAdminPassword(): Promise<string> {
  try {
    const row = await db
      .select()
      .from(systemSettings)
      .where(eq(systemSettings.key, "admin_password"))
      .limit(1);

    if (row.length > 0 && row[0].value) {
      return row[0].value;
    }
  } catch (err) {
    console.error("Failed to fetch admin password from db:", err);
  }
  return "admin123";
}

export function generateAdminToken(password: string): string {
  // Simple deterministic token based on password + secret
  const buffer = Buffer.from(`${password}:${ADMIN_SECRET}`);
  return buffer.toString("base64");
}

export async function verifyAdminToken(token: string | null | undefined): Promise<boolean> {
  if (!token) return false;
  const currentPassword = await getAdminPassword();
  const expectedToken = generateAdminToken(currentPassword);
  return token === expectedToken;
}

export async function isCurrentUserAdmin(): Promise<boolean> {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get(ADMIN_COOKIE_NAME)?.value;
    return await verifyAdminToken(token);
  } catch {
    return false;
  }
}

export { ADMIN_COOKIE_NAME };
