export function formatFileSize(bytes?: number | null): string {
  if (!bytes || bytes === 0) return "Unknown size";
  const k = 1024;
  const sizes = ["Bytes", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + " " + sizes[i];
}

export function formatDate(dateInput: string | Date | null | undefined): string {
  if (!dateInput) return "";
  const d = new Date(dateInput);
  if (isNaN(d.getTime())) return "";
  return d.toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  });
}

export function getClientToken(): string {
  if (typeof window === "undefined") return "anon";
  let token = localStorage.getItem("arena_client_token");
  if (!token) {
    token = `client_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
    localStorage.setItem("arena_client_token", token);
  }
  return token;
}
