"use client";

import { useState, useEffect, useTransition } from "react";
import {
  Upload,
  Search,
  SlidersHorizontal,
  Sparkles,
  Shield,
  Layers,
  Heart,
  Eye,
  Camera,
  Share2,
  FolderOpen,
  X,
} from "lucide-react";
import Navbar from "@/components/Navbar";
import ImageCard from "@/components/ImageCard";
import UploadModal from "@/components/UploadModal";
import ImageDetailModal from "@/components/ImageDetailModal";
import { ImageItem } from "@/lib/types";

const CATEGORIES = [
  "All",
  "Nature",
  "Urban",
  "Architecture",
  "Art & Abstract",
  "Food",
  "Wildlife",
  "Tech",
  "Wallpapers",
  "Memes",
];

export default function HomePage() {
  const [images, setImages] = useState<ImageItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [searchQuery, setSearchQuery] = useState("");
  const [sortBy, setSortBy] = useState<"newest" | "likes" | "views" | "featured">("newest");
  const [isAdmin, setIsAdmin] = useState(false);

  // Modals
  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const [selectedImage, setSelectedImage] = useState<ImageItem | null>(null);

  // Fetch images
  useEffect(() => {
    fetchImages();
    checkAdmin();
  }, [selectedCategory, sortBy]);

  const checkAdmin = async () => {
    try {
      const res = await fetch("/api/admin/auth");
      const data = await res.json();
      setIsAdmin(!!data.isAdmin);
    } catch {
      setIsAdmin(false);
    }
  };

  const fetchImages = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (selectedCategory && selectedCategory !== "All") {
        params.append("category", selectedCategory);
      }
      if (searchQuery.trim()) {
        params.append("search", searchQuery.trim());
      }
      if (sortBy) {
        params.append("sort", sortBy);
      }

      const res = await fetch(`/api/images?${params.toString()}`);
      const data = await res.json();
      setImages(data.images || []);
      if (data.isAdmin !== undefined) {
        setIsAdmin(data.isAdmin);
      }
    } catch (err) {
      console.error("Failed to load images:", err);
    } finally {
      setLoading(false);
    }
  };

  // Search debounce
  useEffect(() => {
    const timer = setTimeout(() => {
      fetchImages();
    }, 300);
    return () => clearTimeout(timer);
  }, [searchQuery]);

  const handleUploadSuccess = (newImage: ImageItem) => {
    setImages((prev) => [newImage, ...prev]);
  };

  const handleDeleteImage = async (id: string) => {
    try {
      const res = await fetch(`/api/images/${id}`, { method: "DELETE" });
      if (res.ok) {
        setImages((prev) => prev.filter((img) => img.id !== id));
        if (selectedImage?.id === id) {
          setSelectedImage(null);
        }
      }
    } catch (err) {
      console.error("Delete failed:", err);
    }
  };

  const handleToggleFeature = async (id: string, current: boolean) => {
    try {
      const res = await fetch(`/api/images/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ isFeatured: !current }),
      });
      if (res.ok) {
        setImages((prev) =>
          prev.map((img) => (img.id === id ? { ...img, isFeatured: !current } : img))
        );
      }
    } catch (err) {
      console.error("Feature toggle failed:", err);
    }
  };

  const handleToggleVisibility = async (id: string, current: boolean) => {
    try {
      const res = await fetch(`/api/images/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ isVisible: !current }),
      });
      if (res.ok) {
        setImages((prev) =>
          prev.map((img) => (img.id === id ? { ...img, isVisible: !current } : img))
        );
      }
    } catch (err) {
      console.error("Visibility toggle failed:", err);
    }
  };

  const handleTagFilter = (tag: string) => {
    setSearchQuery(tag);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      {/* Navigation */}
      <Navbar
        onOpenUpload={() => setIsUploadOpen(true)}
        isAdmin={isAdmin}
        onAdminLogout={() => setIsAdmin(false)}
      />

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-indigo-900 via-slate-900 to-slate-950 px-4 py-16 text-white sm:px-6 lg:px-8">
        {/* Glow decoration */}
        <div className="pointer-events-none absolute -top-40 left-1/2 -translate-x-1/2 h-96 w-96 rounded-full bg-indigo-500/20 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-20 right-10 h-72 w-72 rounded-full bg-violet-500/15 blur-3xl" />

        <div className="relative mx-auto max-w-4xl text-center">
          {/* Badge */}
          <div className="mb-4 inline-flex items-center gap-2 rounded-full bg-indigo-500/10 px-3.5 py-1.5 text-xs font-semibold text-indigo-300 ring-1 ring-indigo-500/30 backdrop-blur-md">
            <Sparkles className="h-3.5 w-3.5 text-indigo-400" />
            <span>Open & Free Community • Everyone Can Upload</span>
          </div>

          <h1 className="text-3xl font-extrabold tracking-tight sm:text-5xl lg:text-6xl text-transparent bg-clip-text bg-gradient-to-r from-white via-slate-100 to-indigo-200">
            Share and Discover Images
          </h1>

          <p className="mx-auto mt-4 max-w-2xl text-sm leading-relaxed text-slate-300 sm:text-base">
            Upload your favorite photos, digital artwork, wallpapers, or memes.
            Anyone can upload in seconds with zero friction.
          </p>

          {/* Call-to-actions */}
          <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
            <button
              onClick={() => setIsUploadOpen(true)}
              className="inline-flex items-center gap-2.5 rounded-xl bg-gradient-to-r from-indigo-500 to-violet-600 px-6 py-3.5 text-sm font-bold text-white shadow-lg shadow-indigo-500/30 transition-all hover:from-indigo-400 hover:to-violet-500 hover:scale-105 active:scale-95 cursor-pointer"
              id="hero-upload-btn"
            >
              <Upload className="h-4 w-4" />
              <span>Upload Your Image Now</span>
            </button>

            <a
              href="/admin"
              className="inline-flex items-center gap-2 rounded-xl border border-slate-700 bg-slate-800/80 px-4 py-3.5 text-xs font-semibold text-slate-300 backdrop-blur-md transition-colors hover:border-slate-600 hover:bg-slate-700/80 hover:text-white"
            >
              <Shield className="h-3.5 w-3.5 text-amber-400" />
              <span>Admin Portal</span>
              <span className="rounded bg-slate-900 px-1.5 py-0.5 text-[10px] text-slate-400">
                admin123
              </span>
            </a>
          </div>

          {/* Fast Features */}
          <div className="mt-10 grid grid-cols-2 gap-3 sm:grid-cols-4 text-xs text-slate-400">
            <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-3">
              <span className="block font-semibold text-white">Open to All</span>
              <span>No signup needed</span>
            </div>
            <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-3">
              <span className="block font-semibold text-white">Drag & Drop</span>
              <span>Or paste image URL</span>
            </div>
            <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-3">
              <span className="block font-semibold text-white">Full Resolution</span>
              <span>Fast free downloads</span>
            </div>
            <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-3">
              <span className="block font-semibold text-white">Admin Controls</span>
              <span>100% working & managed</span>
            </div>
          </div>
        </div>
      </section>

      {/* Main Gallery Area */}
      <main className="mx-auto flex-1 w-full max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        {/* Controls: Search, Categories, Sort */}
        <div className="space-y-4">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            {/* Search Bar */}
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3.5 top-3 h-4 w-4 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search images, tags (#nature), or uploaders..."
                className="w-full rounded-xl border border-slate-200 bg-white py-2.5 pl-10 pr-9 text-sm text-slate-900 shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery("")}
                  className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600"
                >
                  <X className="h-4 w-4" />
                </button>
              )}
            </div>

            {/* Sort & Count */}
            <div className="flex items-center justify-between sm:justify-end gap-3">
              <span className="text-xs font-medium text-slate-500">
                {images.length} {images.length === 1 ? "image" : "images"}
              </span>

              <div className="flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 py-1.5 text-xs shadow-sm">
                <SlidersHorizontal className="h-3.5 w-3.5 text-slate-400" />
                <span className="text-slate-500 font-medium">Sort:</span>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as any)}
                  className="bg-transparent font-semibold text-slate-800 focus:outline-none cursor-pointer"
                >
                  <option value="newest">Newest First</option>
                  <option value="likes">Most Liked</option>
                  <option value="views">Most Viewed</option>
                  <option value="featured">Featured First</option>
                </select>
              </div>
            </div>
          </div>

          {/* Category Chips */}
          <div className="flex gap-1.5 overflow-x-auto pb-2 scrollbar-none">
            {CATEGORIES.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`whitespace-nowrap rounded-xl px-3.5 py-1.5 text-xs font-semibold transition-all ${
                  selectedCategory === cat
                    ? "bg-indigo-600 text-white shadow-sm"
                    : "bg-white text-slate-600 border border-slate-200 hover:border-slate-300 hover:bg-slate-50"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Gallery Grid */}
        <div className="mt-8">
          {loading ? (
            <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3">
              {[...Array(6)].map((_, i) => (
                <div
                  key={i}
                  className="aspect-[4/3] w-full animate-pulse rounded-2xl bg-slate-200"
                />
              ))}
            </div>
          ) : images.length === 0 ? (
            <div className="flex flex-col items-center justify-center rounded-3xl border-2 border-dashed border-slate-200 bg-white p-12 text-center shadow-sm">
              <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-indigo-50 text-indigo-600">
                <Camera className="h-8 w-8" />
              </div>
              <h3 className="mt-4 text-lg font-bold text-slate-900">
                No images found
              </h3>
              <p className="mt-1 max-w-sm text-xs text-slate-500">
                {searchQuery || selectedCategory !== "All"
                  ? "Try clearing filters or search queries to see more photos."
                  : "Be the very first community member to upload an image!"}
              </p>
              <button
                onClick={() => setIsUploadOpen(true)}
                className="mt-5 inline-flex items-center gap-2 rounded-xl bg-indigo-600 px-4 py-2.5 text-xs font-semibold text-white shadow-sm hover:bg-indigo-500"
              >
                <Upload className="h-4 w-4" />
                <span>Upload an Image</span>
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3">
              {images.map((image) => (
                <ImageCard
                  key={image.id}
                  image={image}
                  onClick={() => setSelectedImage(image)}
                  isAdmin={isAdmin}
                  onDelete={handleDeleteImage}
                  onToggleFeature={handleToggleFeature}
                  onToggleVisibility={handleToggleVisibility}
                />
              ))}
            </div>
          )}
        </div>
      </main>

      {/* Footer */}
      <footer className="mt-auto border-t border-slate-200 bg-white py-8 text-center text-xs text-slate-500">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 px-4 sm:flex-row sm:px-6 lg:px-8">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-800">PixelShare</span>
            <span>• Open Image Community Gallery</span>
          </div>
          <div className="flex items-center gap-4 text-xs font-medium">
            <button
              onClick={() => setIsUploadOpen(true)}
              className="text-indigo-600 hover:underline"
            >
              Upload Image
            </button>
            <a href="/admin" className="text-slate-600 hover:text-slate-900">
              Admin Portal (admin123)
            </a>
          </div>
        </div>
      </footer>

      {/* Upload Modal (Everyone can upload!) */}
      <UploadModal
        isOpen={isUploadOpen}
        onClose={() => setIsUploadOpen(false)}
        onUploadSuccess={handleUploadSuccess}
      />

      {/* Image Detail Lightbox Modal */}
      <ImageDetailModal
        image={selectedImage}
        isOpen={!!selectedImage}
        onClose={() => setSelectedImage(null)}
        isAdmin={isAdmin}
        onDelete={handleDeleteImage}
        onToggleFeature={handleToggleFeature}
        onToggleVisibility={handleToggleVisibility}
        onTagClick={handleTagFilter}
      />
    </div>
  );
}
