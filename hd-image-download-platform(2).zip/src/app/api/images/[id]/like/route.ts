import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { images, imageLikes } from "@/db/schema";
import { and, eq, sql } from "drizzle-orm";

export async function POST(
  request: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await context.params;
    const body = await request.json().catch(() => ({}));
    const clientToken = body.clientToken || request.headers.get("x-client-token") || "anon-client";

    // Check if user already liked this image
    const existingLike = await db
      .select()
      .from(imageLikes)
      .where(and(eq(imageLikes.imageId, id), eq(imageLikes.clientToken, clientToken)))
      .limit(1);

    let isLiked = false;
    let newLikesCount = 0;

    if (existingLike.length > 0) {
      // Unlike
      await db
        .delete(imageLikes)
        .where(eq(imageLikes.id, existingLike[0].id));

      const [updated] = await db
        .update(images)
        .set({ likesCount: sql`GREATEST(${images.likesCount} - 1, 0)` })
        .where(eq(images.id, id))
        .returning();

      newLikesCount = updated?.likesCount ?? 0;
      isLiked = false;
    } else {
      // Like
      const likeId = `like_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
      await db.insert(imageLikes).values({
        id: likeId,
        imageId: id,
        clientToken,
      });

      const [updated] = await db
        .update(images)
        .set({ likesCount: sql`${images.likesCount} + 1` })
        .where(eq(images.id, id))
        .returning();

      newLikesCount = updated?.likesCount ?? 1;
      isLiked = true;
    }

    return NextResponse.json({
      success: true,
      isLiked,
      likesCount: newLikesCount,
    });
  } catch (error) {
    console.error("Like error:", error);
    return NextResponse.json({ error: "Failed to toggle like" }, { status: 500 });
  }
}
