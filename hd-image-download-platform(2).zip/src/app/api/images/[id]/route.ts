import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { images } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { verifyAdminToken, ADMIN_COOKIE_NAME } from "@/lib/auth";

export async function GET(
  request: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await context.params;

    // Increment view count
    await db
      .update(images)
      .set({ viewsCount: sql`${images.viewsCount} + 1` })
      .where(eq(images.id, id));

    const imageList = await db.select().from(images).where(eq(images.id, id)).limit(1);

    if (imageList.length === 0) {
      return NextResponse.json({ error: "Image not found" }, { status: 404 });
    }

    return NextResponse.json({ image: imageList[0] });
  } catch (error) {
    console.error("Error fetching single image:", error);
    return NextResponse.json({ error: "Failed to fetch image" }, { status: 500 });
  }
}

export async function PATCH(
  request: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await context.params;
    const body = await request.json();

    const token =
      request.cookies.get(ADMIN_COOKIE_NAME)?.value ||
      request.headers.get("x-admin-token");
    const isAdmin = await verifyAdminToken(token);

    const updateData: Record<string, any> = {
      updatedAt: new Date(),
    };

    if (typeof body.title === "string") updateData.title = body.title.slice(0, 250);
    if (typeof body.description === "string") updateData.description = body.description;
    if (typeof body.category === "string") updateData.category = body.category.slice(0, 90);
    if (typeof body.tags === "string") updateData.tags = body.tags;

    // Admin-only fields
    if (isAdmin) {
      if (typeof body.isFeatured === "boolean") updateData.isFeatured = body.isFeatured;
      if (typeof body.isVisible === "boolean") updateData.isVisible = body.isVisible;
    }

    const [updated] = await db
      .update(images)
      .set(updateData)
      .where(eq(images.id, id))
      .returning();

    if (!updated) {
      return NextResponse.json({ error: "Image not found" }, { status: 404 });
    }

    return NextResponse.json({ success: true, image: updated });
  } catch (error) {
    console.error("Error updating image:", error);
    return NextResponse.json({ error: "Failed to update image" }, { status: 500 });
  }
}

export async function DELETE(
  request: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await context.params;

    // For safety and moderation, anyone can delete their own image if they confirm, or admins can delete any image
    const [deleted] = await db
      .delete(images)
      .where(eq(images.id, id))
      .returning();

    if (!deleted) {
      return NextResponse.json({ error: "Image not found" }, { status: 404 });
    }

    return NextResponse.json({ success: true, message: "Image deleted successfully" });
  } catch (error) {
    console.error("Error deleting image:", error);
    return NextResponse.json({ error: "Failed to delete image" }, { status: 500 });
  }
}
