import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { images } from "@/db/schema";
import { ensureSeeded } from "@/lib/seed";
import { verifyAdminToken, ADMIN_COOKIE_NAME } from "@/lib/auth";
import { desc, eq, ilike, or, and, sql } from "drizzle-orm";

export async function GET(request: NextRequest) {
  await ensureSeeded();

  const searchParams = request.nextUrl.searchParams;
  const category = searchParams.get("category");
  const search = searchParams.get("search");
  const sort = searchParams.get("sort") || "newest";
  const limitParam = parseInt(searchParams.get("limit") || "60", 10);
  const includeHidden = searchParams.get("includeHidden") === "true";

  // Check admin token if includeHidden is true
  const token = request.cookies.get(ADMIN_COOKIE_NAME)?.value ||
    request.headers.get("x-admin-token");
  const isAdmin = await verifyAdminToken(token);

  try {
    const conditions = [];

    // Unless admin explicitly asks for hidden images, only show visible ones
    if (!isAdmin || !includeHidden) {
      conditions.push(eq(images.isVisible, true));
    }

    if (category && category !== "All" && category !== "all") {
      conditions.push(eq(images.category, category));
    }

    if (search && search.trim()) {
      const query = `%${search.trim()}%`;
      conditions.push(
        or(
          ilike(images.title, query),
          ilike(images.description, query),
          ilike(images.tags, query),
          ilike(images.uploaderName, query)
        )
      );
    }

    let orderByClause;
    switch (sort) {
      case "likes":
        orderByClause = desc(images.likesCount);
        break;
      case "views":
        orderByClause = desc(images.viewsCount);
        break;
      case "featured":
        orderByClause = [desc(images.isFeatured), desc(images.createdAt)];
        break;
      case "oldest":
        orderByClause = images.createdAt;
        break;
      case "newest":
      default:
        orderByClause = desc(images.createdAt);
        break;
    }

    const whereClause = conditions.length > 0 ? and(...conditions) : undefined;

    const items = await db
      .select()
      .from(images)
      .where(whereClause)
      .orderBy(...(Array.isArray(orderByClause) ? orderByClause : [orderByClause]))
      .limit(limitParam);

    // Get categories counts
    const categoryRows = await db
      .select({
        category: images.category,
        count: sql<number>`count(*)::int`,
      })
      .from(images)
      .where(isAdmin ? undefined : eq(images.isVisible, true))
      .groupBy(images.category);

    const categories = [
      { name: "All", count: items.length },
      ...categoryRows.map((r) => ({
        name: r.category || "General",
        count: Number(r.count),
      })),
    ];

    return NextResponse.json({
      images: items,
      categories,
      isAdmin,
    });
  } catch (error) {
    console.error("Error fetching images:", error);
    return NextResponse.json(
      { error: "Failed to fetch images", images: [] },
      { status: 500 }
    );
  }
}
