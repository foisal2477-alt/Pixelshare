import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { images, systemSettings } from "@/db/schema";
import { ensureSeeded } from "@/lib/seed";
import { verifyAdminToken, ADMIN_COOKIE_NAME } from "@/lib/auth";
import { count, eq, sql, sum } from "drizzle-orm";

export async function GET(request: NextRequest) {
  await ensureSeeded();

  const token =
    request.cookies.get(ADMIN_COOKIE_NAME)?.value ||
    request.headers.get("x-admin-token");
  const isAdmin = await verifyAdminToken(token);

  if (!isAdmin) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const totalCount = await db.select({ count: count() }).from(images);
    const visibleCount = await db
      .select({ count: count() })
      .from(images)
      .where(eq(images.isVisible, true));
    const featuredCount = await db
      .select({ count: count() })
      .from(images)
      .where(eq(images.isFeatured, true));

    const aggregates = await db
      .select({
        totalViews: sum(images.viewsCount),
        totalLikes: sum(images.likesCount),
        totalSize: sum(images.fileSize),
      })
      .from(images);

    const settingsRows = await db.select().from(systemSettings);
    const settingsMap: Record<string, string> = {};
    settingsRows.forEach((r) => {
      settingsMap[r.key] = r.value;
    });

    const categoryStats = await db
      .select({
        category: images.category,
        count: count(),
      })
      .from(images)
      .groupBy(images.category);

    return NextResponse.json({
      stats: {
        totalImages: Number(totalCount[0]?.count || 0),
        visibleImages: Number(visibleCount[0]?.count || 0),
        hiddenImages:
          Number(totalCount[0]?.count || 0) - Number(visibleCount[0]?.count || 0),
        featuredImages: Number(featuredCount[0]?.count || 0),
        totalViews: Number(aggregates[0]?.totalViews || 0),
        totalLikes: Number(aggregates[0]?.totalLikes || 0),
        totalSizeBytes: Number(aggregates[0]?.totalSize || 0),
      },
      settings: {
        allowPublicUploads: settingsMap["allow_public_uploads"] !== "false",
        maxFileSizeMb: parseInt(settingsMap["max_file_size_mb"] || "15", 10),
        siteName: settingsMap["site_name"] || "PixelShare Gallery",
      },
      categories: categoryStats,
    });
  } catch (error) {
    console.error("Admin settings error:", error);
    return NextResponse.json({ error: "Failed to fetch admin settings" }, { status: 500 });
  }
}

export async function PATCH(request: NextRequest) {
  await ensureSeeded();

  const token =
    request.cookies.get(ADMIN_COOKIE_NAME)?.value ||
    request.headers.get("x-admin-token");
  const isAdmin = await verifyAdminToken(token);

  if (!isAdmin) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const body = await request.json();

    if (typeof body.allowPublicUploads === "boolean") {
      await db
        .insert(systemSettings)
        .values({
          key: "allow_public_uploads",
          value: body.allowPublicUploads ? "true" : "false",
        })
        .onConflictDoUpdate({
          target: systemSettings.key,
          set: {
            value: body.allowPublicUploads ? "true" : "false",
            updatedAt: new Date(),
          },
        });
    }

    if (body.newPassword && typeof body.newPassword === "string") {
      if (body.newPassword.trim().length < 4) {
        return NextResponse.json(
          { error: "Admin password must be at least 4 characters long" },
          { status: 400 }
        );
      }
      await db
        .insert(systemSettings)
        .values({
          key: "admin_password",
          value: body.newPassword.trim(),
        })
        .onConflictDoUpdate({
          target: systemSettings.key,
          set: {
            value: body.newPassword.trim(),
            updatedAt: new Date(),
          },
        });
    }

    if (typeof body.siteName === "string" && body.siteName.trim()) {
      await db
        .insert(systemSettings)
        .values({
          key: "site_name",
          value: body.siteName.trim(),
        })
        .onConflictDoUpdate({
          target: systemSettings.key,
          set: {
            value: body.siteName.trim(),
            updatedAt: new Date(),
          },
        });
    }

    return NextResponse.json({
      success: true,
      message: "Settings updated successfully",
    });
  } catch (error) {
    console.error("Error updating settings:", error);
    return NextResponse.json({ error: "Failed to update settings" }, { status: 500 });
  }
}
