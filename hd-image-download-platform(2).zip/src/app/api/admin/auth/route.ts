import { NextRequest, NextResponse } from "next/server";
import { cookies } from "next/headers";
import { ensureSeeded } from "@/lib/seed";
import {
  getAdminPassword,
  generateAdminToken,
  verifyAdminToken,
  ADMIN_COOKIE_NAME,
} from "@/lib/auth";

export async function GET(request: NextRequest) {
  await ensureSeeded();
  const token = request.cookies.get(ADMIN_COOKIE_NAME)?.value ||
    request.headers.get("x-admin-token");

  const isAdmin = await verifyAdminToken(token);
  return NextResponse.json({ isAdmin });
}

export async function POST(request: NextRequest) {
  await ensureSeeded();
  try {
    const body = await request.json();
    const { password } = body;

    const actualPassword = await getAdminPassword();

    if (!password || password !== actualPassword) {
      return NextResponse.json(
        { success: false, error: "Invalid admin password. Default is 'admin123'." },
        { status: 401 }
      );
    }

    const token = generateAdminToken(actualPassword);
    const cookieStore = await cookies();
    cookieStore.set(ADMIN_COOKIE_NAME, token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      path: "/",
      maxAge: 60 * 60 * 24 * 7, // 7 days
    });

    return NextResponse.json({
      success: true,
      token,
      message: "Admin authentication successful",
    });
  } catch (error) {
    console.error("Admin auth error:", error);
    return NextResponse.json(
      { success: false, error: "Authentication failed" },
      { status: 500 }
    );
  }
}

export async function DELETE() {
  const cookieStore = await cookies();
  cookieStore.delete(ADMIN_COOKIE_NAME);
  return NextResponse.json({ success: true, message: "Logged out" });
}
