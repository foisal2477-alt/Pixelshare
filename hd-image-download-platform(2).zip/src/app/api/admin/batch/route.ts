import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { images } from "@/db/schema";
import { ensureSeeded } from "@/lib/seed";
import { verifyAdminToken, ADMIN_COOKIE_NAME } from "@/lib/auth";
import { inArray } from "drizzle-orm";

export async function POST(request: NextRequest) {
  await ensureSeeded();

  const token =
    request.cookies.get(ADMIN_COOKIE_NAME)?.value ||
    request.headers.get("x-admin-token");
  const isAdmin = await verifyAdminToken(token);

  if (!isAdmin) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const body = await request.json();
    const { action, ids } = body;

    if (action === "reset_demo") {
      // Clear images and re-seed
      await db.delete(images);
      await ensureSeeded();
      return NextResponse.json({
        success: true,
        message: "Gallery reset to initial sample images",
      });
    }

    if (!Array.isArray(ids) || ids.length === 0) {
      return NextResponse.json(
        { error: "No image IDs provided" },
        { status: 400 }
      );
    }

    if (action === "delete") {
      await db.delete(images).where(inArray(images.id, ids));
      return NextResponse.json({
        success: true,
        message: `Deleted ${ids.length} image(s)`,
      });
    }

    if (action === "hide") {
      await db
        .update(images)
        .set({ isVisible: false, updatedAt: new Date() })
        .where(inArray(images.id, ids));
      return NextResponse.json({
        success: true,
        message: `Hidden ${ids.length} image(s)`,
      });
    }

    if (action === "show") {
      await db
        .update(images)
        .set({ isVisible: true, updatedAt: new Date() })
        .where(inArray(images.id, ids));
      return NextResponse.json({
        success: true,
        message: `Made ${ids.length} image(s) visible`,
      });
    }

    return NextResponse.json({ error: "Invalid action" }, { status: 400 });
  } catch (error) {
    console.error("Batch operation error:", error);
    return NextResponse.json(
      { error: "Batch operation failed" },
      { status: 500 }
    );
  }
}
