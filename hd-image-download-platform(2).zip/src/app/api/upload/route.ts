import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { images, systemSettings } from "@/db/schema";
import { ensureSeeded } from "@/lib/seed";
import { eq } from "drizzle-orm";

export async function POST(request: NextRequest) {
  await ensureSeeded();

  try {
    // Check if public uploads are allowed
    const publicSetting = await db
      .select()
      .from(systemSettings)
      .where(eq(systemSettings.key, "allow_public_uploads"))
      .limit(1);

    const allowPublic = publicSetting.length === 0 || publicSetting[0].value === "true";
    if (!allowPublic) {
      // Check if admin is uploading
      const token = request.cookies.get("arena_admin_auth")?.value;
      if (!token) {
        return NextResponse.json(
          { error: "Public image uploads are temporarily paused by the administrator." },
          { status: 403 }
        );
      }
    }

    const contentType = request.headers.get("content-type") || "";

    let title = "";
    let description = "";
    let category = "General";
    let tags = "";
    let uploaderName = "Anonymous";
    let imageUrl = "";
    let fileName = "upload.jpg";
    let mimeType = "image/jpeg";
    let fileSize = 0;

    if (contentType.includes("multipart/form-data")) {
      const formData = await request.formData();
      const file = formData.get("file") as File | null;
      title = (formData.get("title") as string) || "";
      description = (formData.get("description") as string) || "";
      category = (formData.get("category") as string) || "General";
      tags = (formData.get("tags") as string) || "";
      uploaderName = (formData.get("uploaderName") as string) || "Anonymous";

      if (file && typeof file === "object" && file.size > 0) {
        // Validate MIME type
        const validTypes = [
          "image/jpeg",
          "image/png",
          "image/webp",
          "image/gif",
          "image/svg+xml",
          "image/avif",
        ];
        if (!validTypes.includes(file.type)) {
          return NextResponse.json(
            { error: "Unsupported file type. Please upload a JPG, PNG, WEBP, GIF, or SVG image." },
            { status: 400 }
          );
        }

        // Limit size: 15MB
        const maxBytes = 15 * 1024 * 1024;
        if (file.size > maxBytes) {
          return NextResponse.json(
            { error: "File size exceeds 15MB limit. Please upload a smaller image." },
            { status: 400 }
          );
        }

        const arrayBuffer = await file.arrayBuffer();
        const buffer = Buffer.from(arrayBuffer);
        imageUrl = `data:${file.type};base64,${buffer.toString("base64")}`;
        fileName = file.name || "uploaded-image";
        mimeType = file.type;
        fileSize = file.size;

        if (!title.trim()) {
          // generate title from file name
          title = fileName.replace(/\.[^/.]+$/, "").replace(/[-_]/g, " ");
          title = title.charAt(0).toUpperCase() + title.slice(1);
        }
      } else {
        // Check if imageUrl was provided in form data
        const urlField = formData.get("imageUrl") as string;
        if (urlField && urlField.trim()) {
          imageUrl = urlField.trim();
        } else {
          return NextResponse.json(
            { error: "Please provide an image file or an image URL." },
            { status: 400 }
          );
        }
      }
    } else if (contentType.includes("application/json")) {
      const body = await request.json();
      title = body.title || "";
      description = body.description || "";
      category = body.category || "General";
      tags = body.tags || "";
      uploaderName = body.uploaderName || "Anonymous";
      imageUrl = body.imageUrl || "";
      fileName = body.fileName || "image.jpg";
      mimeType = body.mimeType || "image/jpeg";
      fileSize = body.fileSize || 0;

      if (!imageUrl || !imageUrl.trim()) {
        return NextResponse.json(
          { error: "Image URL or data is required." },
          { status: 400 }
        );
      }
    } else {
      return NextResponse.json(
        { error: "Invalid content type. Use multipart/form-data or application/json." },
        { status: 400 }
      );
    }

    if (!title.trim()) {
      title = "Untitled Image";
    }

    const id = `img_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;

    const [newImage] = await db
      .insert(images)
      .values({
        id,
        title: title.trim().slice(0, 250),
        description: description ? description.trim() : null,
        imageUrl,
        fileName: fileName.slice(0, 250),
        fileSize,
        mimeType,
        category: category.trim().slice(0, 90),
        tags: tags.trim(),
        uploaderName: (uploaderName || "Anonymous").trim().slice(0, 90),
        isFeatured: false,
        isVisible: true,
        likesCount: 0,
        viewsCount: 0,
      })
      .returning();

    return NextResponse.json({
      success: true,
      image: newImage,
      message: "Image uploaded successfully!",
    });
  } catch (error) {
    console.error("Upload error:", error);
    return NextResponse.json(
      { error: "Failed to upload image. Please try again." },
      { status: 500 }
    );
  }
}
