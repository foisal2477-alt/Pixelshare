"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import {
  Shield,
  ShieldCheck,
  Lock,
  Key,
  Unlock,
  Eye,
  EyeOff,
  Trash2,
  Star,
  RefreshCw,
  LogOut,
  ArrowLeft,
  CheckCircle2,
  AlertCircle,
  FileImage,
  TrendingUp,
  HardDrive,
  Users,
  Settings,
  Sliders,
  Check,
  Upload,
} from "lucide-react";
import { ImageItem, AdminStats, SystemSettingsData } from "@/lib/types";
import { formatDate, formatFileSize } from "@/lib/client-utils";
import UploadModal from "@/components/UploadModal";

export default function AdminPage() {
  const [isAdmin, setIsAdmin] = useState<boolean | null>(null);
  const [password, setPassword] = useState("admin123");
  const [showPassword, setShowPassword] = useState(false);
  const [loginError, setLoginError] = useState("");
  const [loginLoading, setLoginLoading] = useState(false);

  // Admin Dashboard State
  const [activeTab, setActiveTab] = useState<"images" | "settings">("images");
  const [imagesList, setImagesList] = useState<ImageItem[]>([]);
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [settings, setSettings] = useState<SystemSettingsData | null>(null);
  const [isLoadingData, setIsLoadingData] = useState(true);

  // Filters & Selection
  const [filterStatus, setFilterStatus] = useState<"all" | "visible" | "hidden" | "featured">("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [actionMessage, setActionMessage] = useState("");

  // Settings form
  const [allowPublic, setAllowPublic] = useState(true);
  const [newPasswordInput, setNewPasswordInput] = useState("");
  const [settingsSaving, setSettingsSaving] = useState(false);

  // Upload modal trigger
  const [isUploadOpen, setIsUploadOpen] = useState(false);

  // Check initial admin session
  useEffect(() => {
    checkAdminStatus();
  }, []);

  const checkAdminStatus = async () => {
    try {
      const res = await fetch("/api/admin/auth");
      const data = await res.json();
      setIsAdmin(!!data.isAdmin);
      if (data.isAdmin) {
        fetchAdminData();
      }
    } catch {
      setIsAdmin(false);
    }
  };

  const fetchAdminData = async () => {
    setIsLoadingData(true);
    try {
      // 1. Fetch all images (including hidden)
      const imgRes = await fetch("/api/images?includeHidden=true&limit=100");
      const imgData = await imgRes.json();
      setImagesList(imgData.images || []);

      // 2. Fetch admin stats and settings
      const setRes = await fetch("/api/admin/settings");
      if (setRes.ok) {
        const setData = await setRes.json();
        setStats(setData.stats);
        setSettings(setData.settings);
        setAllowPublic(setData.settings?.allowPublicUploads ?? true);
      }
    } catch (err) {
      console.error("Failed to load admin data:", err);
    } finally {
      setIsLoadingData(false);
    }
  };

  const handleLogin = async (pwToUse?: string) => {
    setLoginError("");
    setLoginLoading(true);
    const pass = pwToUse || password;

    try {
      const res = await fetch("/api/admin/auth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password: pass }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || "Login failed. Default password is 'admin123'.");
      }

      setIsAdmin(true);
      fetchAdminData();
    } catch (err: any) {
      setLoginError(err.message || "Failed to authenticate as admin");
    } finally {
      setLoginLoading(false);
    }
  };

  const handleLogout = async () => {
    try {
      await fetch("/api/admin/auth", { method: "DELETE" });
      setIsAdmin(false);
    } catch (err) {
      console.error("Logout failed:", err);
    }
  };

  const toggleSelectAll = () => {
    if (selectedIds.length === filteredImages.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(filteredImages.map((img) => img.id));
    }
  };

  const toggleSelectId = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  };

  const handleToggleVisibility = async (id: string, current: boolean) => {
    try {
      const res = await fetch(`/api/images/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ isVisible: !current }),
      });
      if (res.ok) {
        setImagesList((prev) =>
          prev.map((img) => (img.id === id ? { ...img, isVisible: !current } : img))
        );
        flashActionMessage(`Image ${!current ? "made visible" : "hidden"}`);
      }
    } catch (err) {
      console.error("Toggle visibility failed:", err);
    }
  };

  const handleToggleFeature = async (id: string, current: boolean) => {
    try {
      const res = await fetch(`/api/images/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ isFeatured: !current }),
      });
      if (res.ok) {
        setImagesList((prev) =>
          prev.map((img) => (img.id === id ? { ...img, isFeatured: !current } : img))
        );
        flashActionMessage(`Image ${!current ? "featured on top" : "unfeatured"}`);
      }
    } catch (err) {
      console.error("Toggle feature failed:", err);
    }
  };

  const handleDeleteSingle = async (id: string) => {
    if (!confirm("Are you sure you want to delete this image? This action cannot be undone.")) {
      return;
    }
    try {
      const res = await fetch(`/api/images/${id}`, { method: "DELETE" });
      if (res.ok) {
        setImagesList((prev) => prev.filter((img) => img.id !== id));
        setSelectedIds((prev) => prev.filter((i) => i !== id));
        flashActionMessage("Image deleted successfully");
      }
    } catch (err) {
      console.error("Delete image failed:", err);
    }
  };

  const handleBatchAction = async (action: "delete" | "hide" | "show") => {
    if (selectedIds.length === 0) return;
    if (
      action === "delete" &&
      !confirm(`Are you sure you want to permanently delete ${selectedIds.length} image(s)?`)
    ) {
      return;
    }

    try {
      const res = await fetch("/api/admin/batch", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action, ids: selectedIds }),
      });
      const data = await res.json();
      if (res.ok) {
        flashActionMessage(data.message || "Batch action complete");
        fetchAdminData();
        setSelectedIds([]);
      }
    } catch (err) {
      console.error("Batch error:", err);
    }
  };

  const handleResetDemoData = async () => {
    if (!confirm("This will replace all images with fresh default sample images. Continue?")) {
      return;
    }
    try {
      const res = await fetch("/api/admin/batch", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "reset_demo" }),
      });
      if (res.ok) {
        flashActionMessage("Demo images restored!");
        fetchAdminData();
      }
    } catch (err) {
      console.error("Reset error:", err);
    }
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setSettingsSaving(true);
    try {
      const payload: Record<string, any> = {
        allowPublicUploads: allowPublic,
      };
      if (newPasswordInput.trim()) {
        payload.newPassword = newPasswordInput.trim();
      }

      const res = await fetch("/api/admin/settings", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (res.ok) {
        flashActionMessage("Settings updated successfully!");
        setNewPasswordInput("");
        fetchAdminData();
      } else {
        alert(data.error || "Failed to update settings");
      }
    } catch (err) {
      console.error("Save settings error:", err);
    } finally {
      setSettingsSaving(false);
    }
  };

  const flashActionMessage = (msg: string) => {
    setActionMessage(msg);
    setTimeout(() => setActionMessage(""), 4000);
  };

  // Filter images
  const filteredImages = imagesList.filter((img) => {
    if (filterStatus === "visible" && !img.isVisible) return false;
    if (filterStatus === "hidden" && img.isVisible) return false;
    if (filterStatus === "featured" && !img.isFeatured) return false;

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchTitle = img.title.toLowerCase().includes(q);
      const matchUploader = (img.uploaderName || "").toLowerCase().includes(q);
      const matchCategory = (img.category || "").toLowerCase().includes(q);
      const matchTags = (img.tags || "").toLowerCase().includes(q);
      return matchTitle || matchUploader || matchCategory || matchTags;
    }
    return true;
  });

  // Login view if not admin
  if (isAdmin === false) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center bg-slate-900 px-4 py-12 text-slate-100">
        <div className="w-full max-w-md space-y-6">
          {/* Header */}
          <div className="text-center">
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-indigo-600 text-white shadow-xl shadow-indigo-600/30">
              <Shield className="h-7 w-7" />
            </div>
            <h1 className="mt-4 text-2xl font-bold tracking-tight text-white">
              Admin Portal
            </h1>
            <p className="mt-1 text-sm text-slate-400">
              Manage uploaded images, moderate gallery, and configure settings.
            </p>
          </div>

          {/* Login Card */}
          <div className="rounded-2xl border border-slate-800 bg-slate-950 p-6 shadow-2xl">
            {loginError && (
              <div className="mb-4 flex items-center gap-2 rounded-xl bg-rose-950/60 p-3 text-xs text-rose-300 ring-1 ring-rose-700/50">
                <AlertCircle className="h-4 w-4 shrink-0 text-rose-400" />
                <span>{loginError}</span>
              </div>
            )}

            {/* Quick 1-Click Login Button */}
            <div className="mb-5 rounded-xl border border-indigo-500/30 bg-indigo-950/40 p-4 text-center">
              <div className="flex items-center justify-center gap-2 text-xs font-semibold text-indigo-300">
                <Key className="h-4 w-4 text-indigo-400" />
                <span>Default Password: <code className="rounded bg-indigo-900/60 px-1.5 py-0.5 text-indigo-200">admin123</code></span>
              </div>
              <button
                type="button"
                onClick={() => handleLogin("admin123")}
                disabled={loginLoading}
                className="mt-3 w-full rounded-xl bg-indigo-600 py-2.5 text-xs font-bold text-white shadow-lg shadow-indigo-600/30 hover:bg-indigo-500 active:scale-95 transition-all cursor-pointer"
                id="quick-admin-login-button"
              >
                {loginLoading ? "Authenticating..." : "⚡ Quick 1-Click Admin Login"}
              </button>
            </div>

            <div className="relative my-4 flex items-center justify-center">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-slate-800" />
              </div>
              <span className="relative bg-slate-950 px-3 text-[11px] font-medium uppercase tracking-wider text-slate-500">
                Or type password
              </span>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleLogin();
              }}
              className="space-y-4"
            >
              <div>
                <label className="mb-1 block text-xs font-medium text-slate-300">
                  Password
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter admin password"
                    className="w-full rounded-xl border border-slate-700 bg-slate-900 px-3.5 py-2.5 pr-10 text-sm text-white focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/30"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-200"
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={loginLoading}
                className="w-full rounded-xl border border-slate-700 bg-slate-800 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-slate-700 active:scale-98"
              >
                {loginLoading ? "Logging in..." : "Sign In to Admin"}
              </button>
            </form>
          </div>

          <div className="flex items-center justify-between text-xs text-slate-500">
            <Link
              href="/"
              className="inline-flex items-center gap-1.5 text-slate-400 hover:text-white"
            >
              <ArrowLeft className="h-3.5 w-3.5" />
              Back to Public Gallery
            </Link>
            <span>Public uploads remain open to everyone</span>
          </div>
        </div>
      </div>
    );
  }

  // Admin Dashboard view
  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      {/* Top Banner / Nav */}
      <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/95 backdrop-blur-md">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-3">
            <Link
              href="/"
              className="flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-slate-900"
            >
              <ArrowLeft className="h-4 w-4" />
              <span>Public Gallery</span>
            </Link>
            <span className="text-slate-300">|</span>
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-indigo-600 text-white">
                <ShieldCheck className="h-4 w-4" />
              </div>
              <span className="font-bold text-slate-900">Admin Command Center</span>
              <span className="rounded-full bg-amber-100 px-2 py-0.5 text-[11px] font-semibold text-amber-800">
                Active Session
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsUploadOpen(true)}
              className="inline-flex items-center gap-1.5 rounded-xl bg-indigo-600 px-3.5 py-2 text-xs font-semibold text-white shadow-sm hover:bg-indigo-500"
            >
              <Upload className="h-3.5 w-3.5" />
              <span>Upload Image</span>
            </button>

            <button
              onClick={handleLogout}
              className="inline-flex items-center gap-1.5 rounded-xl border border-slate-200 px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-100"
            >
              <LogOut className="h-3.5 w-3.5" />
              <span>Log Out</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        {/* Action toast */}
        {actionMessage && (
          <div className="mb-6 flex items-center justify-between rounded-xl bg-emerald-50 px-4 py-3 text-sm font-medium text-emerald-800 ring-1 ring-emerald-600/20">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-emerald-600" />
              <span>{actionMessage}</span>
            </div>
            <button
              onClick={() => setActionMessage("")}
              className="text-xs text-emerald-600 hover:text-emerald-900"
            >
              Dismiss
            </button>
          </div>
        )}

        {/* Stats Grid */}
        <div className="mb-8 grid grid-cols-2 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <div className="rounded-2xl border border-slate-200/80 bg-white p-5 shadow-sm">
            <div className="flex items-center justify-between text-slate-500">
              <span className="text-xs font-semibold uppercase tracking-wider">
                Total Images
              </span>
              <FileImage className="h-4 w-4 text-indigo-600" />
            </div>
            <p className="mt-2 text-3xl font-extrabold text-slate-900">
              {stats?.totalImages ?? imagesList.length}
            </p>
            <p className="mt-1 text-xs text-slate-500">
              {stats?.visibleImages ?? 0} public • {stats?.hiddenImages ?? 0} hidden
            </p>
          </div>

          <div className="rounded-2xl border border-slate-200/80 bg-white p-5 shadow-sm">
            <div className="flex items-center justify-between text-slate-500">
              <span className="text-xs font-semibold uppercase tracking-wider">
                Total Views
              </span>
              <Eye className="h-4 w-4 text-sky-600" />
            </div>
            <p className="mt-2 text-3xl font-extrabold text-slate-900">
              {stats?.totalViews ?? 0}
            </p>
            <p className="mt-1 text-xs text-slate-500">Total image impressions</p>
          </div>

          <div className="rounded-2xl border border-slate-200/80 bg-white p-5 shadow-sm">
            <div className="flex items-center justify-between text-slate-500">
              <span className="text-xs font-semibold uppercase tracking-wider">
                Total Likes
              </span>
              <TrendingUp className="h-4 w-4 text-rose-600" />
            </div>
            <p className="mt-2 text-3xl font-extrabold text-slate-900">
              {stats?.totalLikes ?? 0}
            </p>
            <p className="mt-1 text-xs text-slate-500">Community engagements</p>
          </div>

          <div className="rounded-2xl border border-slate-200/80 bg-white p-5 shadow-sm">
            <div className="flex items-center justify-between text-slate-500">
              <span className="text-xs font-semibold uppercase tracking-wider">
                Public Uploads
              </span>
              <HardDrive className="h-4 w-4 text-emerald-600" />
            </div>
            <p className="mt-2 text-2xl font-extrabold text-slate-900">
              {allowPublic ? (
                <span className="text-emerald-600">Enabled</span>
              ) : (
                <span className="text-amber-600">Disabled</span>
              )}
            </p>
            <p className="mt-1 text-xs text-slate-500">
              Storage: {formatFileSize(stats?.totalSizeBytes)}
            </p>
          </div>
        </div>

        {/* Tab switcher */}
        <div className="mb-6 flex border-b border-slate-200">
          <button
            onClick={() => setActiveTab("images")}
            className={`border-b-2 px-6 py-3 text-sm font-semibold transition-colors ${
              activeTab === "images"
                ? "border-indigo-600 text-indigo-600"
                : "border-transparent text-slate-500 hover:text-slate-800"
            }`}
          >
            Manage Images ({imagesList.length})
          </button>
          <button
            onClick={() => setActiveTab("settings")}
            className={`border-b-2 px-6 py-3 text-sm font-semibold transition-colors ${
              activeTab === "settings"
                ? "border-indigo-600 text-indigo-600"
                : "border-transparent text-slate-500 hover:text-slate-800"
            }`}
          >
            Gallery & Security Settings
          </button>
        </div>

        {/* TAB 1: MANAGE IMAGES */}
        {activeTab === "images" && (
          <div className="space-y-4">
            {/* Action Bar */}
            <div className="flex flex-col gap-3 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm md:flex-row md:items-center md:justify-between">
              {/* Search & Filter pills */}
              <div className="flex flex-1 flex-wrap items-center gap-2">
                <input
                  type="text"
                  placeholder="Search by title, uploader, tag..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="rounded-xl border border-slate-200 px-3.5 py-1.5 text-xs text-slate-800 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 w-full sm:w-64"
                />

                <div className="flex items-center gap-1 rounded-xl bg-slate-100 p-1">
                  {(["all", "visible", "hidden", "featured"] as const).map((status) => (
                    <button
                      key={status}
                      onClick={() => setFilterStatus(status)}
                      className={`rounded-lg px-2.5 py-1 text-xs font-semibold capitalize transition-all ${
                        filterStatus === status
                          ? "bg-white text-indigo-600 shadow-sm"
                          : "text-slate-600 hover:text-slate-900"
                      }`}
                    >
                      {status}
                    </button>
                  ))}
                </div>
              </div>

              {/* Batch Actions */}
              <div className="flex flex-wrap items-center gap-2">
                {selectedIds.length > 0 && (
                  <>
                    <span className="text-xs font-medium text-slate-500">
                      {selectedIds.length} selected
                    </span>
                    <button
                      onClick={() => handleBatchAction("show")}
                      className="rounded-xl bg-emerald-50 px-2.5 py-1.5 text-xs font-semibold text-emerald-700 hover:bg-emerald-100"
                    >
                      Show
                    </button>
                    <button
                      onClick={() => handleBatchAction("hide")}
                      className="rounded-xl bg-slate-100 px-2.5 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-200"
                    >
                      Hide
                    </button>
                    <button
                      onClick={() => handleBatchAction("delete")}
                      className="rounded-xl bg-rose-50 px-2.5 py-1.5 text-xs font-semibold text-rose-700 hover:bg-rose-100"
                    >
                      Delete
                    </button>
                  </>
                )}

                <button
                  onClick={fetchAdminData}
                  title="Refresh images"
                  className="rounded-xl border border-slate-200 p-2 text-slate-600 hover:bg-slate-100"
                >
                  <RefreshCw className="h-4 w-4" />
                </button>
              </div>
            </div>

            {/* Images Table / List */}
            <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-slate-600">
                  <thead className="border-b border-slate-200 bg-slate-50 text-[11px] font-bold uppercase tracking-wider text-slate-500">
                    <tr>
                      <th className="p-4 w-10">
                        <input
                          type="checkbox"
                          checked={
                            filteredImages.length > 0 &&
                            selectedIds.length === filteredImages.length
                          }
                          onChange={toggleSelectAll}
                          className="rounded border-slate-300 text-indigo-600"
                        />
                      </th>
                      <th className="p-4">Image</th>
                      <th className="p-4">Title & Details</th>
                      <th className="p-4">Uploader</th>
                      <th className="p-4">Stats</th>
                      <th className="p-4">Status</th>
                      <th className="p-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredImages.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="p-8 text-center text-slate-400">
                          No images found matching criteria.
                        </td>
                      </tr>
                    ) : (
                      filteredImages.map((img) => (
                        <tr
                          key={img.id}
                          className={`hover:bg-slate-50/70 transition-colors ${
                            selectedIds.includes(img.id) ? "bg-indigo-50/40" : ""
                          }`}
                        >
                          <td className="p-4">
                            <input
                              type="checkbox"
                              checked={selectedIds.includes(img.id)}
                              onChange={() => toggleSelectId(img.id)}
                              className="rounded border-slate-300 text-indigo-600"
                            />
                          </td>

                          <td className="p-4">
                            <div className="relative h-14 w-20 overflow-hidden rounded-lg border border-slate-200 bg-slate-100">
                              {/* eslint-disable-next-line @next/next/no-img-element */}
                              <img
                                src={img.imageUrl}
                                alt={img.title}
                                className="h-full w-full object-cover"
                              />
                            </div>
                          </td>

                          <td className="p-4">
                            <p className="font-semibold text-slate-900">{img.title}</p>
                            <p className="text-[11px] text-slate-400">
                              {img.category || "General"} • {formatFileSize(img.fileSize)}
                            </p>
                            {img.tags && (
                              <p className="mt-0.5 text-[10px] text-slate-400 truncate max-w-xs">
                                #{img.tags.replace(/,/g, " #")}
                              </p>
                            )}
                          </td>

                          <td className="p-4">
                            <p className="font-medium text-slate-800">
                              {img.uploaderName || "Anonymous"}
                            </p>
                            <p className="text-[11px] text-slate-400">
                              {formatDate(img.createdAt)}
                            </p>
                          </td>

                          <td className="p-4">
                            <div className="space-y-0.5">
                              <span className="block text-slate-700">
                                <strong>{img.viewsCount || 0}</strong> views
                              </span>
                              <span className="block text-slate-500">
                                <strong>{img.likesCount || 0}</strong> likes
                              </span>
                            </div>
                          </td>

                          <td className="p-4">
                            <div className="flex flex-col gap-1 items-start">
                              {img.isVisible ? (
                                <span className="inline-flex items-center gap-1 rounded-md bg-emerald-50 px-2 py-0.5 text-[11px] font-medium text-emerald-700">
                                  <Eye className="h-3 w-3" /> Visible
                                </span>
                              ) : (
                                <span className="inline-flex items-center gap-1 rounded-md bg-rose-50 px-2 py-0.5 text-[11px] font-medium text-rose-700">
                                  <EyeOff className="h-3 w-3" /> Hidden
                                </span>
                              )}
                              {img.isFeatured && (
                                <span className="inline-flex items-center gap-1 rounded-md bg-amber-50 px-2 py-0.5 text-[11px] font-medium text-amber-700">
                                  <Star className="h-3 w-3 fill-current" /> Featured
                                </span>
                              )}
                            </div>
                          </td>

                          <td className="p-4 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              {/* Toggle Featured */}
                              <button
                                onClick={() => handleToggleFeature(img.id, img.isFeatured)}
                                title={img.isFeatured ? "Unfeature" : "Feature on top"}
                                className={`rounded-lg p-1.5 transition-colors ${
                                  img.isFeatured
                                    ? "bg-amber-100 text-amber-700 hover:bg-amber-200"
                                    : "text-slate-400 hover:bg-slate-100 hover:text-slate-600"
                                }`}
                              >
                                <Star
                                  className={`h-4 w-4 ${
                                    img.isFeatured ? "fill-current" : ""
                                  }`}
                                />
                              </button>

                              {/* Toggle Visibility */}
                              <button
                                onClick={() => handleToggleVisibility(img.id, img.isVisible)}
                                title={img.isVisible ? "Hide image" : "Show image"}
                                className={`rounded-lg p-1.5 transition-colors ${
                                  img.isVisible
                                    ? "text-slate-400 hover:bg-slate-100 hover:text-slate-600"
                                    : "bg-rose-100 text-rose-700 hover:bg-rose-200"
                                }`}
                              >
                                {img.isVisible ? (
                                  <Eye className="h-4 w-4" />
                                ) : (
                                  <EyeOff className="h-4 w-4" />
                                )}
                              </button>

                              {/* Delete */}
                              <button
                                onClick={() => handleDeleteSingle(img.id)}
                                title="Delete image"
                                className="rounded-lg p-1.5 text-slate-400 hover:bg-rose-50 hover:text-rose-600"
                              >
                                <Trash2 className="h-4 w-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: SETTINGS */}
        {activeTab === "settings" && (
          <div className="max-w-2xl space-y-6">
            <form
              onSubmit={handleSaveSettings}
              className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm space-y-6"
            >
              <h3 className="text-base font-bold text-slate-900">
                Gallery & Upload Permissions
              </h3>

              {/* Public Upload Switch */}
              <div className="flex items-center justify-between rounded-xl bg-slate-50 p-4">
                <div>
                  <p className="text-sm font-semibold text-slate-900">
                    Allow Public Uploads
                  </p>
                  <p className="text-xs text-slate-500">
                    When enabled, anyone visiting the gallery can upload images freely.
                  </p>
                </div>
                <label className="relative inline-flex cursor-pointer items-center">
                  <input
                    type="checkbox"
                    checked={allowPublic}
                    onChange={(e) => setAllowPublic(e.target.checked)}
                    className="peer sr-only"
                  />
                  <div className="peer h-6 w-11 rounded-full bg-slate-200 after:absolute after:left-[2px] after:top-[2px] after:h-5 after:w-5 after:rounded-full after:bg-white after:transition-all after:content-[''] peer-checked:bg-indigo-600 peer-checked:after:translate-x-full peer-focus:outline-none"></div>
                </label>
              </div>

              {/* Change Admin Password */}
              <div className="border-t border-slate-100 pt-5">
                <label className="block text-xs font-semibold text-slate-700">
                  Update Admin Password
                </label>
                <p className="mb-2 text-xs text-slate-500">
                  Leave blank if you do not want to change it. Default is <code>admin123</code>.
                </p>
                <input
                  type="password"
                  placeholder="New password (min 4 characters)"
                  value={newPasswordInput}
                  onChange={(e) => setNewPasswordInput(e.target.value)}
                  className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-sm text-slate-900 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
              </div>

              <div className="flex justify-end pt-2">
                <button
                  type="submit"
                  disabled={settingsSaving}
                  className="rounded-xl bg-indigo-600 px-5 py-2.5 text-xs font-semibold text-white shadow-sm hover:bg-indigo-500"
                >
                  {settingsSaving ? "Saving..." : "Save Settings"}
                </button>
              </div>
            </form>

            {/* Danger Zone */}
            <div className="rounded-2xl border border-rose-200 bg-rose-50/50 p-6 shadow-sm">
              <h3 className="text-base font-bold text-rose-900">Danger Zone</h3>
              <p className="mt-1 text-xs text-rose-700">
                Restore initial sample gallery images. This will clear existing test uploads.
              </p>
              <button
                type="button"
                onClick={handleResetDemoData}
                className="mt-4 rounded-xl border border-rose-300 bg-white px-4 py-2 text-xs font-semibold text-rose-700 hover:bg-rose-100"
              >
                Reset Gallery to Sample Images
              </button>
            </div>
          </div>
        )}
      </main>

      {/* Upload Modal (accessible directly from admin) */}
      <UploadModal
        isOpen={isUploadOpen}
        onClose={() => setIsUploadOpen(false)}
        onUploadSuccess={(newImg) => {
          setImagesList((prev) => [newImg, ...prev]);
          setIsUploadOpen(false);
          flashActionMessage(`Image "${newImg.title}" uploaded!`);
        }}
      />
    </div>
  );
}
